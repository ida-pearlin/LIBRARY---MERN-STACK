# Page Turner — Library Book Ordering System

A responsive MERN-stack web application for browsing a library book collection, searching and filtering books, adding books to a basket, and placing book orders. Built with MongoDB, Express, React, Vite, and Node.js. The starter collection is inserted into MongoDB the first time the server starts.

## Requirements
- Node.js 18+
- MongoDB Community Server running locally, or a MongoDB Atlas connection string

## Run the app
1. Extract the ZIP and open the project folder in VS Code.
2. Open a terminal in the project folder and install dependencies:
   ```bash
   npm install
   npm run install-all
   ```
3. Create `server/.env` by copying `server/.env.example`. For local MongoDB, the default value works:
   ```env
   MONGO_URI=mongodb://127.0.0.1:27017/library_book_ordering
   PORT=5000
   ```
   For MongoDB Atlas, replace `MONGO_URI` with your Atlas connection string.
4. Make sure MongoDB is running, then start the backend and frontend:
   ```bash
   npm run dev
   ```
5. Open the frontend at **http://localhost:5173**. The API runs at **http://localhost:5000**.

## Features
- Browse the sample library collection
- Search books by title, description, or category
- Filter by category
- Add books to the basket and change quantities
- Enter a customer name and place a book order
- Store book records and orders in MongoDB
- Responsive frontend layout

## MongoDB collections
- `books`: book title, description, price, emoji, and category
- `bookorders`: customer name, ordered items, quantities, total, and timestamp

## API endpoints
- `GET /api/health` — API health check
- `GET /api/books` — list books
- `POST /api/orders` — validate and save a book order

## Notes
The frontend includes a demo collection if the API is offline, but orders can only be saved when the backend and MongoDB are running. The sample catalogue uses illustrative titles and prices; replace them with your library's actual catalogue as needed.
