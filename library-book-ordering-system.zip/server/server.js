import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const bookSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: String,
  price: { type: Number, required: true },
  emoji: String,
  category: String
});
const Book = mongoose.model("Book", bookSchema);

const orderSchema = new mongoose.Schema({
  customerName: { type: String, required: true },
  items: [{ name: String, price: Number, quantity: Number }],
  total: { type: Number, required: true },
  createdAt: { type: Date, default: Date.now }
});
const Order = mongoose.model("BookOrder", orderSchema);

app.get("/api/health", (_req, res) => res.json({ message: "Library book ordering API is running" }));
app.get("/api/books", async (_req, res) => {
  try {
    const books = await Book.find().sort({ name: 1 });
    res.json(books);
  } catch {
    res.status(500).json({ message: "Could not load books" });
  }
});
app.post("/api/orders", async (req, res) => {
  try {
    const { customerName, items, total } = req.body;
    if (!customerName?.trim() || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ message: "Enter your name and add at least one book." });
    }
    const order = await Order.create({ customerName: customerName.trim(), items, total });
    res.status(201).json({ message: "Book order placed successfully!", order });
  } catch {
    res.status(500).json({ message: "Could not save order. Check MongoDB connection." });
  }
});

const defaultBooks = [
  { name: "Atomic Habits", description: "Build good habits and break bad ones", price: 499, emoji: "📘", category: "Self-help" },
  { name: "The Alchemist", description: "A journey of dreams, courage and discovery", price: 299, emoji: "📕", category: "Fiction" },
  { name: "Clean Code", description: "A practical guide to writing better software", price: 699, emoji: "💻", category: "Technology" },
  { name: "Introduction to Algorithms", description: "Essential concepts in computer algorithms", price: 899, emoji: "📗", category: "Academic" },
  { name: "Ikigai", description: "Discover the Japanese secret to a meaningful life", price: 350, emoji: "📙", category: "Self-help" },
  { name: "The Great Gatsby", description: "A classic novel of ambition and the American dream", price: 279, emoji: "📔", category: "Fiction" }
];

async function start() {
  try {
    await mongoose.connect(process.env.MONGO_URI || "mongodb://127.0.0.1:27017/library_book_ordering");
    console.log("Connected to MongoDB");
    if (await Book.countDocuments() === 0) await Book.insertMany(defaultBooks);
    const port = process.env.PORT || 5000;
    app.listen(port, () => console.log(`API running at http://localhost:${port}`));
  } catch (error) {
    console.error("MongoDB connection failed:", error.message);
    console.error("Start MongoDB locally or set MONGO_URI in server/.env");
    process.exit(1);
  }
}
start();
