import { useEffect, useMemo, useState } from "react";

const API = "http://localhost:5000/api";
const fallbackBooks = [
  { _id: "1", name: "Atomic Habits", description: "Build good habits and break bad ones", price: 499, emoji: "📘", category: "Self-help" },
  { _id: "2", name: "The Alchemist", description: "A journey of dreams, courage and discovery", price: 299, emoji: "📕", category: "Fiction" },
  { _id: "3", name: "Clean Code", description: "A practical guide to writing better software", price: 699, emoji: "💻", category: "Technology" },
  { _id: "4", name: "Introduction to Algorithms", description: "Essential concepts in computer algorithms", price: 899, emoji: "📗", category: "Academic" },
  { _id: "5", name: "Ikigai", description: "Discover the Japanese secret to a meaningful life", price: 350, emoji: "📙", category: "Self-help" },
  { _id: "6", name: "The Great Gatsby", description: "A classic novel of ambition and the American dream", price: 279, emoji: "📔", category: "Fiction" }
];

export default function App() {
  const [books, setBooks] = useState(fallbackBooks);
  const [cart, setCart] = useState({});
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [customerName, setCustomerName] = useState("");
  const [message, setMessage] = useState("");
  const [apiOnline, setApiOnline] = useState(false);

  useEffect(() => {
    fetch(`${API}/books`)
      .then(r => { if (!r.ok) throw new Error(); return r.json(); })
      .then(data => { setBooks(data); setApiOnline(true); })
      .catch(() => setApiOnline(false));
  }, []);

  const categories = ["All", ...new Set(books.map(book => book.category).filter(Boolean))];
  const visibleBooks = books.filter(book =>
    (category === "All" || book.category === category) &&
    `${book.name} ${book.description} ${book.category}`.toLowerCase().includes(search.toLowerCase())
  );
  const cartItems = books.filter(book => cart[book._id]).map(book => ({ ...book, quantity: cart[book._id] }));
  const total = useMemo(() => cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0), [cartItems]);

  const changeQty = (id, delta) => setCart(prev => {
    const next = { ...prev };
    next[id] = (next[id] || 0) + delta;
    if (next[id] <= 0) delete next[id];
    return next;
  });

  async function placeOrder() {
    setMessage("");
    if (!customerName.trim()) { setMessage("Please enter your name before placing the order."); return; }
    if (!cartItems.length) { setMessage("Add a book to your basket first."); return; }
    try {
      const response = await fetch(`${API}/orders`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          customerName,
          items: cartItems.map(({ name, price, quantity }) => ({ name, price, quantity })),
          total
        })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.message || "Order failed");
      setMessage(`Order placed successfully! Order ID: ${data.order._id}`);
      setCart({});
      setCustomerName("");
    } catch {
      setMessage("Unable to save your order. Start the backend and connect MongoDB, then try again.");
    }
  }

  return <div className="app">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-icon">✦</span> page<span className="dot">.</span>turner</a>
      <div className="delivery"><span>📚</span><div><small>Your reading destination</small><strong>Books for every mind</strong></div></div>
      <div className="top-actions"><span className={`status ${apiOnline ? "online" : ""}`}>{apiOnline ? "Database connected" : "Demo preview"}</span><a href="#menu" className="menu-link">Browse books</a></div>
    </header>

    <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow">OPEN A BOOK, OPEN A WORLD</span>
          <h1>Find your next<br/><em>great read.</em></h1>
          <p>Explore stories, discover new ideas, and bring your favourite books home.</p>
          <a href="#menu" className="primary-btn">Explore the collection <span>→</span></a>
          <div className="hero-meta"><span>📖 Curated collection</span><span>•</span><span>Knowledge for everyone</span></div>
        </div>
        <div className="hero-art"><div className="art-circle"></div><div className="art-food">📚</div><div className="floating f1">📖</div><div className="floating f2">✏️</div><div className="art-tag">Every book opens<br/><b>a new world</b></div></div>
      </section>

      <section id="menu" className="menu-section">
        <div className="section-head"><div><span className="eyebrow">THE LIBRARY COLLECTION</span><h2>Discover books</h2></div><div className="search-wrap"><span>⌕</span><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search books or authors..." /></div></div>
        <div className="categories">{categories.map(c => <button key={c} className={category === c ? "chip active" : "chip"} onClick={() => setCategory(c)}>{c}</button>)}</div>
        <div className="content-grid">
          <div className="food-grid">{visibleBooks.map((book, i) => <article className="food-card" key={book._id}>
            <div className={`food-art art-${i % 6}`}><span className="food-emoji">{book.emoji || "📚"}</span><span className="heart">♡</span></div>
            <div className="food-info"><div className="food-title"><h3>{book.name}</h3><span className="rating">★ Popular</span></div><p>{book.description}</p><div className="food-bottom"><strong>₹{book.price}</strong><button className="add-btn" onClick={() => changeQty(book._id, 1)}>{cart[book._id] ? `+ Add (${cart[book._id]})` : "+ Add"}</button></div></div>
          </article>)}</div>
          <aside className="cart-card">
            <div className="cart-heading"><div><span className="eyebrow">YOUR READING LIST</span><h2>Your basket <span>📚</span></h2></div><span className="cart-count">{cartItems.reduce((n, item) => n + item.quantity, 0)}</span></div>
            {!cartItems.length ? <div className="empty-cart"><div>📖</div><h3>Your basket is empty</h3><p>Add a book from the collection and it will appear here.</p></div> : <div className="cart-items">{cartItems.map(item => <div className="cart-row" key={item._id}><span className="mini-emoji">{item.emoji}</span><div className="cart-item-name"><b>{item.name}</b><small>₹{item.price} each</small></div><div className="quantity"><button onClick={() => changeQty(item._id, -1)}>−</button><span>{item.quantity}</span><button onClick={() => changeQty(item._id, 1)}>+</button></div></div>)}</div>}
            <div className="bill"><div><span>Subtotal</span><b>₹{total}</b></div><div><span>Order handling</span><b>{total ? "₹0" : "₹0"}</b></div><div className="grand-total"><span>Total</span><strong>₹{total}</strong></div></div>
            <label className="name-label" htmlFor="customer">Your name</label><input id="customer" className="name-input" value={customerName} onChange={e => setCustomerName(e.target.value)} placeholder="Enter your name" />
            <button className="checkout" onClick={placeOrder}>Place book order <span>→</span></button>
            {message && <p className="message">{message}</p>}
            <p className="secure">📚 Your next chapter starts here</p>
          </aside>
        </div>
      </section>
    </main>
    <footer><a className="brand" href="#">✦ page<span className="dot">.</span>turner</a><span>Stories, knowledge and imagination.</span><span>© 2026 Page Turner Library</span></footer>
  </div>;
}
